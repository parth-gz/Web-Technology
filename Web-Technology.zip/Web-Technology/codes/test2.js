var app=angular.module("towork" , [])


app.controller('Todocontroller',function ($scope){
    $scope.task=''
    $scope.taskslist=[]
    $scope.isUpdating=false
    $scope.erro=""
    $scope.curr_index=null

    $scope.addTasks = function(){
        if($scope.new_task.trim()===""){
           $scope.erro="plse add mesage"
           return ;
        }
        if($scope.isUpdating){
            $scope.taskslist[$scope.curr_index]=$scope.new_task;
            $scope.isUpdating=false
            $scope.curr_index=null
        }
        else{
            $scope.taskslist.push($scope.new_task)
        }
        $scope.erro=""    
        
        $scope.new_task=""

    }
  
    $scope.Update =function(index){
        $scope.isUpdating=true 
        $scope.curr_index=index 
        $scope.new_task=$scope.taskslist[index]
    }

    $scope.Delete =function(index){
        $scope.taskslist.splice(index,1)
    }
    $scope.new_task=""

})