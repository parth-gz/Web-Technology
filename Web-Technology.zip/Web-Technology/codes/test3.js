var app=angular.module("todo",[]);

app.controller('ram',function($scope){
    $scope.task='';
    $scope.error='';
    $scope.tasks=[];
    $scope.isUpdateing=false;
        
    $scope.addtask=function (){
         
        if($scope.task.trim()===''){
            $scope.error="plse inter the value"
            return;
        }
        else{

            $scope.tasks.push($scope.task);
    
        }
       $scope.task=''
    }
})