  // Initialize the AngularJS app
  var app = angular.module('todoApp', []);

  // Create the controller
  app.controller('TodoController', function ($scope) {
    // Initialize tasks array
    $scope.tasks = [];
    $scope.newTask = '';
    $scope.isUpdating = false;
    $scope.currentIndex = null;

    // Add or update a task
    $scope.addOrUpdateTask = function () {
      if ($scope.newTask.trim() === '') return; // Prevent empty input
      if ($scope.isUpdating) {
        // Update the task
        $scope.tasks[$scope.currentIndex] = $scope.newTask;
        $scope.isUpdating = false;
        $scope.currentIndex = null;
      }
       else {
        // Add a new task
        $scope.tasks.push($scope.newTask);
      }
      $scope.newTask = ''; // Clear the input field
    };

    // Delete a task
    $scope.deleteTask = function (index) {
      $scope.tasks.splice(index, 1);
    };

    // Edit a task
    $scope.editTask = function (index) {
      $scope.newTask = $scope.tasks[index];
      $scope.isUpdating = true;
      $scope.currentIndex = index;
       console.log($scope.currentIndex)
    };
  });