import React, { useState } from "react";

export default function App() {
  // State to manage the counter value
  const [count, setCount] = useState(0);

  // Increment the counter
  const increment = () => {
    setCount(count + 1);
  };

  // Decrement the counter
  const decrement = () => {
    setCount(count - 1);
  };

  // Reset the counter
  const reset = () => {
    setCount(0);
  };

  return (
    <div style={styles.container}>
      <h1>Simple Counter App</h1>
      <h2>Count: {count}</h2>
      <div style={styles.buttonContainer}>
        <button style={styles.button} onClick={increment}>
          Increment
        </button>
        <button style={styles.button} onClick={decrement}>
          Decrement
        </button>
        <button style={styles.button} onClick={reset}>
          Reset
        </button>
      </div>
    </div>
  );
}

// Inline styles for the app
const styles = {
  container: {
    textAlign: "center",
    marginTop: "50px",
    fontFamily: "Arial, sans-serif",
  },
  buttonContainer: {
    marginTop: "20px",
  },
  button: {
    margin: "5px",
    padding: "10px 20px",
    fontSize: "16px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    backgroundColor: "#f0f0f0",
    cursor: "pointer",
  },
};
