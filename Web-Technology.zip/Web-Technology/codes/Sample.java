package com.sres;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class Sample
 */
public class Sample extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sample() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. insert  2. update 3. delete  4. display
		int x=Integer.parseInt(request.getParameter("ch"));
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Class is loaded !!");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/operations_db","root","");
			
			if(con!=null) {
				System.out.println("Database Connection Is Established !!");
				if(x==1) {
					// insert
					int eid=Integer.parseInt(request.getParameter("eid"));
					String ename=request.getParameter("ename");
					int esal=Integer.parseInt(request.getParameter("esal"));
					String edept=request.getParameter("edept");
				PreparedStatement ps=con.prepareStatement("insert into emp (empid, empname, empsal, empdept) values (?,?,?,?)");
				ps.setInt(1,eid);
				ps.setString(2, ename);
				ps.setInt(3, esal);
				ps.setString(4, edept);
				int row_aff=ps.executeUpdate();
				System.out.println("Number of rows Affected : "+row_aff);
				}
				if(x==2) {
					// update
					String ename=request.getParameter("ename");
					int esal=Integer.parseInt(request.getParameter("esal"));
					String edept=request.getParameter("edept");
					int eid=Integer.parseInt(request.getParameter("eid"));
					PreparedStatement ps=con.prepareStatement("update emp set empname=?, empsal=?, empdept=? where empid=?");
					
					ps.setString(1, ename);
					ps.setInt(2, esal);
					ps.setString(3, edept);
					ps.setInt(4,eid);
					
					int row_aff=ps.executeUpdate();
					System.out.println("Number of rows Affected : "+row_aff);
					
				}
				if(x==3) {
					// delete
					int eid=Integer.parseInt(request.getParameter("eid"));
					PreparedStatement ps=con.prepareStatement("delete from emp where empid=?");
					
					ps.setInt(1, eid);
					int row_aff=ps.executeUpdate();
					System.out.println("Number of rows Affected : "+row_aff);
					
				}
				
				if(x==4) {
					// display
					PreparedStatement ps=con.prepareStatement("select * from emp");
					ResultSet res= ps.executeQuery();
					
					System.out.println("EId EName ESalary EDept");
					while(res.next()) {
						System.out.print(res.getInt(1)+" ");
						System.out.print(res.getString(2)+" ");
						System.out.print(res.getInt(3)+" ");
						System.out.print(res.getString(4)+" ");
						System.out.println("");
					}
				}
			}
			else {
				
			}
			
		}
		
		catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
